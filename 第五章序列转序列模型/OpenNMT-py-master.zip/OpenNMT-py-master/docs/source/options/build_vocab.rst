Build Vocab
===========

.. argparse::
    :filename: ../onmt/bin/build_vocab.py
    :func: _get_parser
    :prog: build_vocab.py

    Transform/BART : @before
        .. Caution:: This transform will not take effect when building vocabulary.

    Transform/SwitchOut : @before
        .. Caution:: This transform will not take effect when building vocabulary.
