Train
=====

.. argparse::
    :filename: ../onmt/bin/train.py
    :func: _get_parser
    :prog: train.py