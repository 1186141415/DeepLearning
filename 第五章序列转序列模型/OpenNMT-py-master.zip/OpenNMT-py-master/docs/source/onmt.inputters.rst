Data Loaders
=================

Data Readers
-------------

.. autoexception:: onmt.inputters.datareader_base.MissingDependencyException

.. autoclass:: onmt.inputters.DataReaderBase
    :members:

.. autoclass:: onmt.inputters.TextDataReader
    :members:


Dataset
--------

.. autoclass:: onmt.inputters.Dataset
    :members:
