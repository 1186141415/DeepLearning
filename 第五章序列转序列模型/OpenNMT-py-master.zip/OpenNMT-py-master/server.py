#!/usr/bin/env python
from onmt.bin.server import main


if __name__ == "__main__":
    main()
